let numeroSecreto = Math.floor(Math.random() * 100) + 1;
let tentativas = 0;

function verificar() {
  let palpite = Number(document.getElementById("palpite").value);
  let mensagem = document.getElementById("mensagem");
  let textoTentativas = document.getElementById("tentativas");

  if (palpite < 1 || palpite > 100 || isNaN(palpite)) {
    mensagem.textContent = "Digite um número válido entre 1 e 100.";
    return;
  }

  tentativas++;
  textoTentativas.textContent = "Tentativas: " + tentativas;

  if (palpite === numeroSecreto) {
    mensagem.textContent = "Parabéns! Você acertou o número!";
  } else if (palpite < numeroSecreto) {
    mensagem.textContent = "O número é maior.";
  } else {
    mensagem.textContent = "O número é menor.";
  }
}

function reiniciar() {
  numeroSecreto = Math.floor(Math.random() * 100) + 1;
  tentativas = 0;
  document.getElementById("palpite").value = "";
  document.getElementById("mensagem").textContent = "";
  document.getElementById("tentativas").textContent = "Tentativas: 0";
}