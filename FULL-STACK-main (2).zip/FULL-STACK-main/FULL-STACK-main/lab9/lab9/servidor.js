const express = require('express');
const bodyParser = require('body-parser');

const { createClient } = require('@supabase/supabase-js');

const app = express();

app.use(express.static(__dirname));

app.use(bodyParser.urlencoded({ extended: false }));

app.set('view engine', 'ejs');

const supabase = createClient(
    'https://ybgqunqggyrpmawhuaxo.supabase.co',
    'sb_publishable_xAK62B63AhBIs0jexVMGuQ_7gTUh8C6'
);

app.listen(80, () => {
    console.log('Servidor rodando');
});

app.get('/', (req, res) => {
    res.redirect('/blog');
});

app.get('/blog', async (req, res) => {

    const { data, error } = await supabase
        .from('posts')
        .select('*');

    console.log(data);
    console.log(error);

    res.render('blog', {
        posts: data || []
    });
});

app.get('/cadastro', (req, res) => {
    res.sendFile(__dirname + '/cadastrar_post.html');
});

app.post('/cadastrar', async (req, res) => {

    const { data, error } = await supabase
        .from('posts')
        .insert([
            {
                titulo: req.body.titulo,
                resumo: req.body.resumo,
                conteudo: req.body.conteudo
            }
        ]);

    console.log(data);
    console.log(error);

    res.redirect('/blog');
});